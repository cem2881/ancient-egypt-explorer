MEDJAY 6.0 — MODÜLER PROJE

Klasör yapısı:
- index.html: oyun arayüzü ve giriş sayfası
- src/main.js: Three.js oyun kodu
- terrain/heightmap.png: referans görsele göre hazırlanan yükseklik haritası
- assets/models/: 3D modeller için düzenli klasörler
- assets/textures/: doku görselleri
- assets/audio/: müzik ve ses efektleri
- assets/ASSET_MANIFEST.txt: varlık klasörlerinin açıklaması

GITHUB PAGES
Bu klasörün içeriğini mevcut GitHub deposunun ana dizinine yükle.
index.html ana dizinde kalmalı; src, terrain ve assets klasörleri de
index.html ile aynı seviyede olmalı.

MODEL DURUMU
Bu pakette henüz yerel GLB model dosyaları bulunmuyor. main.js içindeki
loadDetailedModels() fonksiyonu modellerin bir kısmını uzak GitHub URL'lerinden
yüklemeyi deniyor. Modeller assets klasörüne indirildiğinde, main.js içindeki
ilgili URL'ler yeni yerel dosya yollarına göre değiştirilmelidir.

Yüksek çözünürlüklü heightmap, oyun kodu tarafından terrain/heightmap.png
konumundan okunur. Oyunu yerel dosya olarak değil, GitHub Pages veya HTTP
sunucusu üzerinden aç.
